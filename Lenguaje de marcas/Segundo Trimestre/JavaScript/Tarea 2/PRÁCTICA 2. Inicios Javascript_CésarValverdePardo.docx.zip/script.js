// Ejercicio 1 de JS César Valverde
console.log(Number("42")); // Así mostramos el número en consola.

// Ejercicio 2 de JS
let pi = Number("3.14"); // Nombramos la variable pi con el valor de 3.14 (Ya que este es el de PI)
console.log(pi); // Mostramos el valor de pi en consola.

// Ejercicio 3 de JS
let numABC = Number("abc"); // Nombramos la variable numABC con el valor de 123
console.log(numABC); // Mostramos el valor de numABC en consola.

// Ejercicio 4 de JS
console.log(Number.isNaN(numABC)); // Comprueba si el valor de numABC es un número

// Ejercicio 5 de JS
let Decimales = Number(4.5678); // Así creamos la variable con el valor de 4.5678
console.log(Decimales.toFixed(2)); // Así mostramos el valor de Decimales en consola mostrando sólo 2

// Ejercicio 5.1 de JS
console.log(Math.round(Decimales)); // Así mostramos el valor de Decimales en consola redondeado.

// Ejercicio 6 de JS
let Ejercicio6 = Number(9.99); // Creamos la variable con el valor
console.log(Math.floor(Ejercicio6)); // Así mostramos el valor de Ejercicio6 en consola truncandolo

// Ejercicio 6.1 de JS
console.log(Math.ceil(Ejercicio6)); // Así mostramos el valor de Ejercicio6 en consola redondeado

// Ejercicio 7 de JS
console.log(Math.round(5.1)); // Así redondeamos el número 5.1


// Ejercicio 8 de JS
let Ejercicio8 = Number(5.1); // Variable...
console.log(Number.isFinite(100)); // Así mostramos el valor de Ejercicio8 en consola redondeado

// Ejercicio 9 de JS
let Ejercicio9 = Number(20); // Variable...
console.log(!isNaN(Ejercicio9));

// Ejercicio 9.1 de JS 
console.log(Number.isInteger(Ejercicio9)); 

// Ejercicio 10
function comprobar(valor) {return (typeof valor === 'number' && !isNaN(valor)) ? "Es un número" : "No es un número";}
console.log(comprobar(Ejercicio9)); // Ejemplo de cómo usarlo

// Ejercicio 11 de JS
let Ejercicio11 = 123.456789; // Variable con el valor de 123.456789
console.log(Ejercicio11.toFixed(1)); // Mostramos el valor de Ejercicio11 en consola mostrando sólo 1 decimal

// Ejercicio 11.1 de JS
console.log(Ejercicio11.toFixed(3)); // Mostramos el valor de Ejercicio11 en consola mostrando sólo 3 decimales

// Ejercicio 12 de JS
let Ejercicio12 = 1000000;
console.log(Ejercicio12.toExponential()); 

// Ejercicio 13 de JS
let Ejercicio13 = 'Hola Mundo';
console.log(Ejercicio13.length); // Muestra la longitud de la variable Ejercicio13

// Ejercicio 13.1 de JS
console.log(Ejercicio13.charAt(0)); // Muestra el primer carácter de la variable Ejercicio13

// Ejercicio 13.2 de JS
console.log(Ejercicio13.lastIndexOf('o')); // Muestra el último carácter de la variable Ejercicio13

// Ejercicio 14 de JS
let Ejercicio14 = 'JavaScript';
console.log(Ejercicio14.toUpperCase()); // Muestra el valor de Ejercicio14 en mayúsculas

// Ejercicio 14.1 de JS
console.log(Ejercicio14.toLowerCase()); // Muestra el valor de Ejercicio14 en minúsculas

// Ejercicio 15 de JS
let Ejercicio15 = "  Hola  ";
console.log(Ejercicio15.trim()); // Muestra el valor de Ejercicio15 en consola quitandole los espacios

// Ejercicio 16 de JS
let Ejercicio16 = 'Programacion';
console.log(Ejercicio16.slice(0,8)); // Cortas desde los carácteres de 0 al 8 para mostrar programa
console.log(Ejercicio16.slice(8,16)); // Cortas desde los carácteres de 8 al 16 para mostrar cion (He puesto 16 por poner pero la longitud es 12);)

// Ejercicio 17 de JS
let Ejercicio17 = "JavaScript es genial";
console.log(Ejercicio17.slice(14,20)); // Cortas desde los carácteres de 14 al 20 para mostrar genial

// Ejercicio 18 de JS
let Ejercicio18 = "abcdef";
console.log(Ejercicio18.slice(2,5)); // Cortas desde los carácteres de 2 al 5 para mostrar cde (Los caráceres de 2 al 5);