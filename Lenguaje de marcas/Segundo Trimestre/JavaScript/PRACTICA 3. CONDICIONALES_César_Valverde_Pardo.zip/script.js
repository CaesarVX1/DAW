// Ejercicio 1 de JS de la tarea 3
let edad = prompt("Introduce tu edad"); // Aquí le decimos al usuario que nos diga el dato
console.log(edad); // Aquí imprimimos la edad en la consola

if (edad < 18) {
    console.log("Eres menor de edad");
} else if (edad >= 18 && edad < 65) {
    console.log("Eres adulto");
} else if (edad >= 65) {
    console.log("Eres anciano/jubilado");
}
// Explicación: Aquí con if elses anidados le decimos que si es menor a 18, es menor, si está entre 18 y 65, es adulto, y si es mayor o igual a 65, es anciano/jubilado

// Ahora con operadores ternarios
let Ej1Ternario = edad < 18 ? "Menor" : edad >= 18 && edad < 65 ? "Adulto" : edad >= 65 ? "Viejo" : "Introduce la edad";
// Es lo mismo que lo de arriba pero en ternario, el primer "" es si se cumple y lo que viene tras los ":" es si no se cumple

// Ejercicio 2 de JS de la tarea 3
console.log("Esta es la tabla del 8, sólo te doy pares, está hecho con un for");
for (let i = 0; i <=20; i+=2) { console.log ("8x" + i + "=" + 8*i);}
// Si la variable i, es menor a 20, le decimos que sume 2, aunque creo que también se puede hacer con el módulo de 2

// Ejercicio 2 de JS de la tarea 3 pero con forEach
console.log(" Tabla del 8, sólo pares, forEach");
let forEach = [0,2,4,6,8,10,12,14,16,18,20];
forEach.forEach(function(n){ console.log("8x" + n + "=" + 8*n);})
// le decimos a forEach que haga un forEach de la función forEach, este toma la función vacía y usa la n cómo variable para almacenar datos
// Y el resto de dentro se explica sólo

// Ejercicio 3 de JS de la tarea 3
let array = [1,2,3,4,5,6,7,8,9,10];
for (let i = 0; i<array.length; i++) { 
    if (array[i] == 7) { console.log("Número 7 encontrado")}
    else {console.log("El 7 no está en la posición" + i);}
}

// Ejercicio 4 de JS de la tarea 3
let sumaTotal = 0;
let numeroIntroducido = 0;
while (numeroIntroducido >=0) {
    numeroIntroducido = parseInt(prompt("Pon otro número"));
    sumaTotal += numeroIntroducido;
}
console.log("La suma total de los números mintroducidos es" + sumaTotal);
// Explicación: 2 variables, sumaTotal y numeroIntroducido, mientras numeroIntroducido sea mayor o igual a 0
// Entonces transformamos con parseInt el número para que ahora pida un prompt (Pon otro número)
// Y cuando esto pasa, en la variable de sumaTotal, se agrega el númeroIntroducido; para que al final se muestre la suma por pantalla